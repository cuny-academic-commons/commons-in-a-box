# OpenLab Attributions

Add formatted attributions to post content. Works for both Classic and Block editor.
