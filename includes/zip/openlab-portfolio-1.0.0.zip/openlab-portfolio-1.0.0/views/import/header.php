<h1><?php _e( 'Import Portfolio', 'openlab-portfolio' ); ?></h1>
<p><?php _e( 'Use this tool to import previously exported Portfolio Archive.', 'openlab-portfolio' ); ?></p>
