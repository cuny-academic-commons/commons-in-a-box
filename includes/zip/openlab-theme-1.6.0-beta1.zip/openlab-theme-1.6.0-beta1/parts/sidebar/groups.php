<div id="sidebar" class="sidebar col-sm-6 col-xs-24 pull-right mobile-dropdown type-groups" role="complementary">
	<div class="sidebar-wrapper">
		<?php get_sidebar( 'group-archive' ); ?>
	</div>
</div>
