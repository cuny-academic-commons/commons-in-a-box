<div id="sidebar" role="complementary">
	<div class="padder">
		<?php dynamic_sidebar( 'wiki-sidebar' ) ?>
	</div>
</div>
